# Advanced Search – Solution Architecture

## 1) Context (why now)
- Link to initiative & vision
- Which requirements (IDs) this satisfies
etc...

## 2) Constraints & assumptions
- e.g., Web + Native, UK/ES/NA, <2s latency, AWS/OpenSearch/Contentful

## 3) Proposed design (high-level)
....